#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.asStateFlow



class ${NAME}ViewModel : ViewModel() {


    private val _state = MutableStateFlow(${NAME}State())
    val state = _state.asStateFlow()
    
    protected val _events = Channel<${NAME}Event>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    
        
    fun onAction(action: ${NAME}Action) {
        when(action) {
            is ${NAME}Action.Navigation -> when(action) {
                else -> TODO("Handle navigation")
            }
            else -> TODO("Handle actions")
        }
    }
}