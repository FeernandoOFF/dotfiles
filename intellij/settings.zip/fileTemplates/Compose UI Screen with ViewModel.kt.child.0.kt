#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME} #end

data class ${NAME}State(
    val paramOne: String = "default",
    val paramTwo: List<String> = emptyList(),
)

sealed interface ${NAME}Action {
    sealed class Navigation : ${NAME}Action {
        data object Back : Navigation()
    }
}
    
sealed interface ${NAME}Event {
    
}