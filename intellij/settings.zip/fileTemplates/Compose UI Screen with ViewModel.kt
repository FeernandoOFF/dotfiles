#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "") package ${PACKAGE_NAME} #end
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import kotlinx.serialization.Serializable


@Serializable
object ${NAME}ScreenRoute : NavRoute {

    @Composable
    override fun Content(navController: NavController) {
        val viewModel: ${NAME}ViewModel = viewModel()
        val state by viewModel.state.collectAsStateWithLifecycle()
        
        LaunchedEffect(Unit) {
            viewModel.events.collect { event ->
                when(event) {
                    else -> TODO()
                }
            }
        }
        ${NAME}Screen(
            uiState = state,
            onAction = viewModel::onAction
        )
    }    
}

@Composable
private fun ${NAME}Screen(
    uiState: ${NAME}State,
    onAction: (${NAME}Action) -> Unit,
) {
    Scaffold { safePadding ->
        Text("Hi", Modifier.padding(safePadding))   
    }
}

@Preview
@Composable
private fun Preview() {
    ${PROJECT_NAME}Theme {
        ${NAME}Screen(
            uiState = ${NAME}State(),
            onAction = {}
        )
    }
}